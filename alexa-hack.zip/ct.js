(function() {
  
  if (window.hasRun) {
    return;
  }
  window.hasRun = true;

  
  browser.runtime.onMessage.addListener((message) => {

      switch (message.command) {
          case "loadurl":
              window.location.href = message.beastURL;
              break;
      }
  });

})();
