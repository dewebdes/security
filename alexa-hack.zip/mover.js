var mvr_links = document.getElementsByTagName('a');
var mvr_int;
var latestur='';
var anyrankint;
function mvr_act(){
	if(document.title.indexOf('noact')>-1){
		clearInterval(mvr_int);
		anyrankint = setInterval(function() { getanyrank(latestur); },(60000*3));
	}else{
		console.log('fire-'+random);
		var min = 0; 
		var max = mvr_links.length-1;  
		var random = parseInt(Math.random() * (max - min) + min); 
		var del = mvr_links[random];
	
		del.scrollIntoView();

		var evObj = document.createEvent( 'Events' );
		evObj.initEvent( 'onmousemove', true, false );
		del.dispatchEvent( evObj );
		console.log('del-'+del.innrText);
		}
}
mvr_int = setInterval(mvr_act,500);
function getanyrank(latestur){
	clearInterval(anyrankint);
	window.location.href = latestur;
}
//setInterval(controllasttab,(6000*1));
