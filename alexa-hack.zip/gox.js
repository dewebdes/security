(function() {
  
  if (window.hasRun) {
    return;
  }
  window.hasRun = true;

  console.log('hi loaded...');

  browser.runtime.onMessage.addListener((message) => {
      switch (message.command) {
          case "testlog":
              console.log("+++ : "+message.txt);
              break;
      }
  });

})();
